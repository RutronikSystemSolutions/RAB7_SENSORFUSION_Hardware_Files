
Project RAB7-SENSORFUSION Rev1:
PCB dimensions 72.30x71.79mm.
2 Layers.
Thickness: 1.55mm FR4.
Mask color: PURPLE (MAGENTA).
Silkscreen color: WHITE.
Finish: Immersion Gold.